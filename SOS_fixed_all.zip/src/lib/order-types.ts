export type OrderStatus =
  | "New"
  | "Processing"
  | "Confirmed"
  | "Delivered"
  | "Cancelled";

export const ORDER_STATUSES: OrderStatus[] = [
  "New",
  "Processing",
  "Confirmed",
  "Delivered",
  "Cancelled",
];

export const DELIVERY_METHODS = {
  delivery: "Առաքում հասցեով",
  pickup: "Վերցնել խանութից",
} as const;

export type DeliveryMethod = keyof typeof DELIVERY_METHODS;

export const STATUS_LABELS_HY: Record<OrderStatus, string> = {
  New: "Նոր",
  Processing: "Մշակման մեջ",
  Confirmed: "Հաստատված",
  Delivered: "Առաքված",
  Cancelled: "Չեղարկված",
};

export const STATUS_EXPLAIN_HY: Record<OrderStatus, string> = {
  New: "Ձեր պատվերն ընդունված է և սպասում է մշակման։",
  Processing: "Ձեր պատվերը մշակվում է մեր թիմի կողմից։",
  Confirmed: "Ձեր պատվերը հաստատված է, շուտով կկապվենք Ձեզ հետ։",
  Delivered: "Ձեր պատվերն առաքված է։ Շնորհակալություն։",
  Cancelled: "Ձեր պատվերը չեղարկվել է։",
};

export interface OrderItemRecord {
  productId?: string | null;
  name: string;
  image: string;
  price: number;
  quantity: number;
  unit: string;
  subtotal: number;
}

export interface OrderRecord {
  id: string;
  orderCode: string;
  customerName: string;
  customerPhone: string;
  customerEmail?: string | null;
  deliveryMethod: string;
  address?: string | null;
  comment?: string | null;
  totalAmount: number;
  status: OrderStatus;
  createdAt: string;
  items: OrderItemRecord[];
}