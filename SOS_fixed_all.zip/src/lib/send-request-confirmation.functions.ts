import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const InputSchema = z.object({
  name: z.string().min(1),
  email: z.string().email(),
});

/**
 * Sends a confirmation email to a customer after they submit a request.
 * Sends from the connected Gmail account via the Lovable connector gateway.
 */
export const sendRequestConfirmation = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => InputSchema.parse(data))
  .handler(async ({ data }) => {
    const subject = "Ձեր հարցումն ընդունվել է — sosshin.am";
    const html = `
      <div style="font-family: Arial, sans-serif; line-height: 1.6; color: #1a1a1a;">
        <p>Սիրելի ${escapeHtml(data.name)},</p>
        <p>Ձեր հարցումն ընդունվել է։ Մեր թիմը շուտով կկապվի Ձեզ հետ և կպատասխանի Ձեր նամակին։</p>
        <p>Եթե հարցը շտապ է, կարող եք զանգահարել՝ <strong>+374 95 506 677</strong>, գրել՝ <strong>vardan-kesoyan@yandex.ru</strong>, կամ այցելել մեզ հետևյալ հասցեով՝ <strong>Արշակունյաց 210/1, տաղավար 235</strong>։</p>
        <p>Շնորհակալություն վստահության համար։</p>
      </div>
    `;

    try {
      const lovableApiKey = process.env.LOVABLE_API_KEY;
      const gmailKey = process.env.GOOGLE_MAIL_API_KEY;
      if (!lovableApiKey || !gmailKey) {
        console.error("Missing LOVABLE_API_KEY or GOOGLE_MAIL_API_KEY");
        return { ok: false as const };
      }

      const raw = createRawEmail(data.email, subject, html);
      const res = await fetch(
        "https://connector-gateway.lovable.dev/google_mail/gmail/v1/users/me/messages/send",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${lovableApiKey}`,
            "X-Connection-Api-Key": gmailKey,
          },
          body: JSON.stringify({ raw }),
        },
      );

      if (!res.ok) {
        const body = await res.text();
        console.error("Gmail send failed", res.status, body);
        return { ok: false as const };
      }
      return { ok: true as const };
    } catch (err) {
      console.error("Confirmation email threw", err);
      return { ok: false as const };
    }
  });

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function createRawEmail(to: string, subject: string, html: string): string {
  const encodedSubject = `=?UTF-8?B?${Buffer.from(subject, "utf-8").toString("base64")}?=`;
  const message = [
    `To: ${to}`,
    `Subject: ${encodedSubject}`,
    "MIME-Version: 1.0",
    'Content-Type: text/html; charset="UTF-8"',
    "Content-Transfer-Encoding: base64",
    "",
    Buffer.from(html, "utf-8").toString("base64"),
  ].join("\r\n");

  return Buffer.from(message, "utf-8")
    .toString("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");
}