import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const SearchInput = z.object({
  query: z.string().trim().min(2).max(120),
});

const SuggestionSchema = z.object({
  name: z.string(),
  barcode: z.string(),
  estimatedPrice: z.number(),
  status: z.string(),
  description: z.string(),
});

export type ProductSuggestion = z.infer<typeof SuggestionSchema>;

type GoogleItem = {
  title?: string;
  snippet?: string;
  link?: string;
  displayLink?: string;
};

async function assertAdmin(context: any) {
  const { data: isAdmin } = await context.supabase.rpc("has_role", {
    _user_id: context.userId,
    _role: "admin",
  });
  const { data: isMain } = await context.supabase.rpc("has_role", {
    _user_id: context.userId,
    _role: "main_admin",
  });
  if (!isAdmin && !isMain) throw new Response("Forbidden", { status: 403 });
}

function cleanSearchText(value: string): string {
  return value
    .replace(/["'`]/g, " ")
    .replace(/[\r\n\t]+/g, " ")
    .replace(/\s{2,}/g, " ")
    .trim()
    .slice(0, 120);
}

function cleanTitle(title: string): string {
  return title
    .replace(/\s[-–—|]\s[^-–—|]{2,80}$/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 120);
}

function makeSku(name: string, index: number): string {
  let hash = 0;
  for (const char of name) hash = (hash * 31 + char.charCodeAt(0)) >>> 0;
  return `SOS-GGL-${String(index + 1).padStart(2, "0")}-${hash.toString(36).toUpperCase().slice(0, 5)}`;
}

function parseEstimatedPrice(text: string): number {
  const amd = text.match(/(?:^|\s)([\d\s.,]{3,})\s*(?:֏|դրամ|AMD|amd|դր\.?)/i);
  if (amd?.[1]) {
    const value = Number(amd[1].replace(/[^\d]/g, ""));
    if (Number.isFinite(value) && value > 0) return value;
  }

  const usd = text.match(/\$\s*([\d\s.,]{1,})/);
  if (usd?.[1]) {
    const value = Number(usd[1].replace(/[^\d.]/g, ""));
    if (Number.isFinite(value) && value > 0) return Math.round(value * 390);
  }

  return 0;
}

function makeDescription(item: GoogleItem): string {
  const source = item.snippet || item.displayLink || item.link || "Google Search արդյունք";
  return source.replace(/\s+/g, " ").trim().slice(0, 95);
}

/**
 * Admin product search powered by Google Custom Search API.
 * The admin writes an approximate product name, Google returns possible matches,
 * and the admin chooses the correct one before saving/editing the final product.
 */
export const searchProducts = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => SearchInput.parse(input))
  .handler(async ({ data, context }): Promise<ProductSuggestion[]> => {
    await assertAdmin(context);

    const apiKey = process.env.GOOGLE_SEARCH_API_KEY;
    const cx = process.env.GOOGLE_SEARCH_ENGINE_ID;
    if (!apiKey || !cx) {
      console.error("[product-search] Missing GOOGLE_SEARCH_API_KEY or GOOGLE_SEARCH_ENGINE_ID");
      return [];
    }

    const safeQuery = cleanSearchText(data.query);
    const url = new URL("https://www.googleapis.com/customsearch/v1");
    url.searchParams.set("key", apiKey);
    url.searchParams.set("cx", cx);
    url.searchParams.set("q", `${safeQuery} լողավազան PVC խողովակ նասոս ֆիլտր գին Հայաստան`);
    url.searchParams.set("num", "6");
    url.searchParams.set("safe", "active");
    url.searchParams.set("gl", "am");

    try {
      const res = await fetch(url.toString());
      if (!res.ok) {
        console.error("[product-search] Google failed", res.status, await res.text());
        return [];
      }

      const json: { items?: GoogleItem[] } = await res.json();
      const seen = new Set<string>();
      const suggestions: ProductSuggestion[] = [];

      for (const item of json.items ?? []) {
        const name = cleanTitle(item.title ?? safeQuery);
        if (!name || seen.has(name.toLowerCase())) continue;
        seen.add(name.toLowerCase());

        const combined = `${item.title ?? ""} ${item.snippet ?? ""}`;
        suggestions.push({
          name,
          barcode: makeSku(name, suggestions.length),
          estimatedPrice: parseEstimatedPrice(combined),
          status: "Google",
          description: makeDescription(item),
        });
      }

      return suggestions.slice(0, 6);
    } catch (err) {
      console.error("[product-search] threw", err);
      return [];
    }
  });
