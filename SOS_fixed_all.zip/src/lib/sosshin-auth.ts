import { useEffect, useState } from "react";
import type { Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

export type AdminState = "loading" | "authed" | "guest";

async function isAdmin(userId: string): Promise<boolean> {
  const { data, error } = await (supabase as any)
    .from("user_roles")
    .select("role")
    .eq("user_id", userId);
  if (error) {
    console.error("Role check failed", error);
    return false;
  }
  return (data ?? []).some(
    (r: any) => r.role === "admin" || r.role === "main_admin",
  );
}

/** Tracks whether the current visitor is a signed-in admin. */
export function useAdminSession() {
  const [state, setState] = useState<AdminState>("loading");
  const [email, setEmail] = useState<string | null>(null);

  useEffect(() => {
    let active = true;

    const resolve = async (session: Session | null) => {
      if (!session) {
        if (active) {
          setState("guest");
          setEmail(null);
        }
        return;
      }
      const admin = await isAdmin(session.user.id);
      if (!active) return;
      if (admin) {
        setState("authed");
        setEmail(session.user.email ?? null);
      } else {
        setState("guest");
        setEmail(null);
      }
    };

    // IMPORTANT: never call other supabase methods (getSession / DB queries)
    // synchronously inside onAuthStateChange — it deadlocks the auth lock.
    // Defer with setTimeout so the callback returns first.
    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      setTimeout(() => resolve(session), 0);
    });

    // Initial check.
    supabase.auth.getSession().then(({ data }) => resolve(data.session));

    return () => {
      active = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  return { state, email };
}

export async function adminSignIn(
  email: string,
  password: string,
): Promise<{ ok: boolean; error?: string }> {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });
  if (error) return { ok: false, error: error.message };
  const admin = await isAdmin(data.user.id);
  if (!admin) {
    await supabase.auth.signOut();
    return { ok: false, error: "Այս հաշիվը ադմին իրավունք չունի։" };
  }
  return { ok: true };
}

export async function adminSignOut() {
  await supabase.auth.signOut();
}