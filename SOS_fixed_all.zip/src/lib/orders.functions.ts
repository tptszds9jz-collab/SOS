import { createServerFn } from "@tanstack/react-start";
import { getRequestUrl, getRequestIP } from "@tanstack/react-start/server";
import { z } from "zod";
import type { OrderRecord, OrderStatus } from "./order-types";
import {
  STATUS_LABELS_HY,
  STATUS_EXPLAIN_HY,
  DELIVERY_METHODS,
} from "./order-types";

const FALLBACK_ORIGIN = "https://kesoyanvardan.lovable.app";

const CartItemInput = z.object({
  productId: z.string().uuid(),
  quantity: z.number().int().min(1).max(9999),
});

const CreateOrderInput = z.object({
  name: z.string().trim().min(1).max(120),
  phone: z.string().trim().min(3).max(40),
  email: z.string().trim().email().max(255).optional().or(z.literal("")),
  deliveryMethod: z.enum(["delivery", "pickup"]),
  address: z.string().trim().max(500).optional().or(z.literal("")),
  comment: z.string().trim().max(1000).optional().or(z.literal("")),
  items: z.array(CartItemInput).min(1).max(100),
});

// Best-effort in-memory rate limiter (per worker instance).
const rateMap = new Map<string, { count: number; ts: number }>();
function rateLimit(key: string, max: number, windowMs: number): boolean {
  const now = Date.now();
  const entry = rateMap.get(key);
  if (!entry || now - entry.ts > windowMs) {
    rateMap.set(key, { count: 1, ts: now });
    return true;
  }
  if (entry.count >= max) return false;
  entry.count += 1;
  return true;
}

function resolveUnit(name: string, unit?: string): string {
  const hay = `${name} ${unit ?? ""}`.toLowerCase();
  if (hay.includes("/մ")) return "մ";
  if (hay.includes("/լ")) return "լ";
  return "հատ";
}

function getOrigin(): string {
  try {
    const url = getRequestUrl();
    if (url) return new URL(url).origin;
  } catch {
    /* ignore */
  }
  return process.env.SITE_URL || FALLBACK_ORIGIN;
}

function gen4(): string {
  return String(Math.floor(Math.random() * 10000)).padStart(4, "0");
}

export const createOrder = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => CreateOrderInput.parse(input))
  .handler(async ({ data }) => {
    let ip = "anon";
    try {
      ip = getRequestIP({ xForwardedFor: true }) ?? "anon";
    } catch {
      /* ignore */
    }
    if (!rateLimit(`order:${ip}`, 8, 60_000)) {
      throw new Response("Too many requests. Please try again later.", { status: 429 });
    }

    if (data.deliveryMethod === "delivery" && !data.address?.trim()) {
      throw new Response("Address is required for delivery.", { status: 400 });
    }

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Authoritative product data from DB (prevents client price tampering).
    const ids = [...new Set(data.items.map((i) => i.productId))];
    const { data: products, error: prodErr } = await supabaseAdmin
      .from("products")
      .select("id, name, price, image, unit")
      .in("id", ids);
    if (prodErr) throw new Error("Failed to load products");

    const productMap = new Map((products ?? []).map((p: any) => [p.id, p]));
    const items = data.items.map((it) => {
      const p = productMap.get(it.productId);
      if (!p) throw new Response("Product not found", { status: 400 });
      const price = Number(p.price) || 0;
      const subtotal = price * it.quantity;
      return {
        product_id: p.id,
        name: p.name,
        image: p.image ?? "",
        price,
        quantity: it.quantity,
        unit: resolveUnit(p.name, p.unit),
        subtotal,
      };
    });

    const totalAmount = items.reduce((s, i) => s + i.subtotal, 0);
    const deliveryLabel = DELIVERY_METHODS[data.deliveryMethod];

    // Insert order with a unique 4-digit code (retry on collision).
    let orderRow: any = null;
    for (let attempt = 0; attempt < 12; attempt++) {
      const code = gen4();
      const { data: inserted, error } = await supabaseAdmin
        .from("orders")
        .insert({
          order_code: code,
          customer_name: data.name,
          customer_phone: data.phone,
          customer_email: data.email?.trim() ? data.email.trim() : null,
          delivery_method: deliveryLabel,
          address: data.deliveryMethod === "delivery" ? (data.address?.trim() || null) : null,
          comment: data.comment?.trim() || null,
          total_amount: totalAmount,
          status: "New",
        })
        .select()
        .single();
      if (!error && inserted) {
        orderRow = inserted;
        break;
      }
      // 23505 = unique violation -> retry with a new code
      if (error && (error as any).code !== "23505") {
        throw new Error("Failed to create order");
      }
    }
    if (!orderRow) throw new Error("Could not generate order code");

    const { error: itemsErr } = await supabaseAdmin
      .from("order_items")
      .insert(items.map((i) => ({ ...i, order_id: orderRow.id })));
    if (itemsErr) {
      console.error("[createOrder] items insert failed", itemsErr);
    }

    const origin = getOrigin();
    const record: OrderRecord = {
      id: orderRow.id,
      orderCode: orderRow.order_code,
      customerName: orderRow.customer_name,
      customerPhone: orderRow.customer_phone,
      customerEmail: orderRow.customer_email,
      deliveryMethod: orderRow.delivery_method,
      address: orderRow.address,
      comment: orderRow.comment,
      totalAmount: Number(orderRow.total_amount) || 0,
      status: orderRow.status as OrderStatus,
      createdAt: orderRow.created_at,
      items: items.map((i) => ({
        productId: i.product_id,
        name: i.name,
        image: i.image,
        price: i.price,
        quantity: i.quantity,
        unit: i.unit,
        subtotal: i.subtotal,
      })),
    };

    // Send emails (never block order success).
    try {
      const emails = await import("./order-emails.server");
      await emails.sendNewOrderAdminEmail(record, origin);
      await emails.sendNewOrderCustomerEmail(record, origin);
    } catch (err) {
      console.error("[createOrder] email error", err);
    }

    return {
      orderCode: record.orderCode,
      trackingPath: `/track-order?code=${record.orderCode}`,
    };
  });

const TrackInput = z.object({
  code: z.string().trim().regex(/^\d{4}$/),
});

export const trackOrder = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => TrackInput.parse(input))
  .handler(async ({ data }) => {
    let ip = "anon";
    try {
      ip = getRequestIP({ xForwardedFor: true }) ?? "anon";
    } catch {
      /* ignore */
    }
    if (!rateLimit(`track:${ip}`, 30, 60_000)) {
      throw new Response("Too many requests. Please try again later.", { status: 429 });
    }

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: order, error } = await supabaseAdmin
      .from("orders")
      .select("id, order_code, status, total_amount, created_at")
      .eq("order_code", data.code)
      .maybeSingle();
    if (error) throw new Error("Lookup failed");
    if (!order) return { found: false as const };

    const { data: items } = await supabaseAdmin
      .from("order_items")
      .select("name, quantity, unit, price, subtotal")
      .eq("order_id", order.id);

    const status = order.status as OrderStatus;
    return {
      found: true as const,
      orderCode: order.order_code,
      status,
      statusLabel: STATUS_LABELS_HY[status] ?? order.status,
      statusExplain: STATUS_EXPLAIN_HY[status] ?? "",
      totalAmount: Number(order.total_amount) || 0,
      createdAt: order.created_at,
      items: (items ?? []).map((i: any) => ({
        name: i.name,
        quantity: Number(i.quantity) || 0,
        unit: i.unit,
        price: Number(i.price) || 0,
        subtotal: Number(i.subtotal) || 0,
      })),
    };
  });