import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const Input = z.object({
  // data URL: data:image/...;base64,xxxx
  image: z.string().min(32).max(8_000_000),
});

/**
 * Identify a product from a captured photo using the Lovable AI gateway
 * (multimodal). Returns a short product name (Armenian) the admin can then
 * use for an online image search.
 */
export const identifyProductFromPhoto = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => Input.parse(input))
  .handler(async ({ data, context }): Promise<{ name: string }> => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    const { data: isMain } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "main_admin",
    });
    if (!isAdmin && !isMain) throw new Response("Forbidden", { status: 403 });

    if (!/^data:image\/[a-zA-Z]+;base64,/.test(data.image)) {
      throw new Response("Invalid image", { status: 400 });
    }

    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("Missing LOVABLE_API_KEY");

    try {
      const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Lovable-API-Key": key,
          "X-Lovable-AIG-SDK": "raw",
        },
        body: JSON.stringify({
          model: "google/gemini-3-flash-preview",
          messages: [
            {
              role: "user",
              content: [
                {
                  type: "text",
                  text:
                    "Identify the pool / plumbing / heating equipment product in this image. " +
                    "Reply with ONLY a short product name in Eastern Armenian (max 6 words), no extra text.",
                },
                { type: "image_url", image_url: { url: data.image } },
              ],
            },
          ],
        }),
      });
      if (!res.ok) {
        console.error("[vision] failed", res.status, await res.text());
        return { name: "" };
      }
      const json: any = await res.json();
      const name = String(json.choices?.[0]?.message?.content ?? "")
        .replace(/[\r\n]+/g, " ")
        .trim()
        .slice(0, 120);
      return { name };
    } catch (err) {
      console.error("[vision] threw", err);
      return { name: "" };
    }
  });