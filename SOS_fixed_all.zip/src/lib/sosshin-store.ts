import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Product, CustomerMessage, AdminUser } from "./sosshin-types";
import type { OrderRecord, OrderStatus } from "./order-types";

// The generated Supabase types don't yet include these tables, so we use a
// loosely-typed client here and map rows to our domain types.
const sb = supabase as unknown as {
  from: (table: string) => any;
  channel: (name: string) => any;
  removeChannel: (channel: unknown) => void;
};

function mapProduct(row: any): Product {
  return {
    id: row.id,
    barcode: row.barcode ?? "",
    name: row.name,
    price: Number(row.price) || 0,
    image: row.image ?? "",
    status: row.status ?? undefined,
    pinned: !!row.pinned,
    createdAt: row.created_at,
    unit: row.unit ?? "",
  };
}

function mapMessage(row: any): CustomerMessage {
  return {
    id: row.id,
    name: row.name,
    phone: row.phone,
    email: row.email ?? undefined,
    message: row.message,
    createdAt: row.created_at,
  };
}

function mapOrder(row: any): OrderRecord {
  return {
    id: row.id,
    orderCode: row.order_code,
    customerName: row.customer_name,
    customerPhone: row.customer_phone,
    customerEmail: row.customer_email ?? undefined,
    deliveryMethod: row.delivery_method,
    address: row.address ?? undefined,
    comment: row.comment ?? undefined,
    totalAmount: Number(row.total_amount) || 0,
    status: (row.status as OrderStatus) ?? "New",
    createdAt: row.created_at,
    items: (row.order_items ?? []).map((i: any) => ({
      productId: i.product_id ?? undefined,
      name: i.name,
      image: i.image ?? "",
      price: Number(i.price) || 0,
      quantity: Number(i.quantity) || 0,
      unit: i.unit ?? "",
      subtotal: Number(i.subtotal) || 0,
    })),
  };
}

export const db = {
  async getProducts(): Promise<Product[]> {
    const { data, error } = await sb
      .from("products")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw error;
    return (data ?? []).map(mapProduct);
  },

  async upsertProduct(p: Product): Promise<void> {
    const payload = {
      id: p.id,
      barcode: p.barcode,
      name: p.name,
      price: p.price,
      image: p.image,
      status: p.status ?? null,
      pinned: p.pinned,
      unit: p.unit ?? "",
    };
    const { error } = await sb.from("products").upsert(payload);
    if (error) throw error;
  },

  async deleteProduct(id: string): Promise<void> {
    const { error } = await sb.from("products").delete().eq("id", id);
    if (error) throw error;
  },

  async getMessages(): Promise<CustomerMessage[]> {
    const { data, error } = await sb
      .from("messages")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw error;
    return (data ?? []).map(mapMessage);
  },

  async insertMessage(m: { name: string; phone: string; email?: string; message: string }): Promise<void> {
    const { error } = await sb.from("messages").insert(m);
    if (error) throw error;
  },

  async deleteMessage(id: string): Promise<void> {
    const { error } = await sb.from("messages").delete().eq("id", id);
    if (error) throw error;
  },

  async getAdmins(): Promise<AdminUser[]> {
    const { data, error } = await sb
      .from("admin_profiles")
      .select("email, role")
      .order("created_at", { ascending: true });
    if (error) throw error;
    return (data ?? []).map((r: any) => ({ email: r.email, role: r.role }));
  },

  async getOrders(): Promise<OrderRecord[]> {
    const { data, error } = await sb
      .from("orders")
      .select("*, order_items(*)")
      .order("created_at", { ascending: false });
    if (error) throw error;
    return (data ?? []).map(mapOrder);
  },
};

/**
 * Live list of products with realtime updates. Used on the public catalog
 * and inside the admin dashboard.
 */
export function useProducts() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    const load = async () => {
      try {
        const rows = await db.getProducts();
        if (active) setProducts(rows);
      } catch (e) {
        console.error("Failed to load products", e);
      } finally {
        if (active) setLoading(false);
      }
    };
    load();

    const channel = sb
      .channel("products-stream")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "products" },
        () => load(),
      )
      .subscribe();

    return () => {
      active = false;
      sb.removeChannel(channel);
    };
  }, []);

  return { products, loading, refresh: () => db.getProducts().then(setProducts) };
}

/** Live list of customer messages (admin only). */
export function useMessages(enabled: boolean) {
  const [messages, setMessages] = useState<CustomerMessage[]>([]);

  useEffect(() => {
    if (!enabled) return;
    let active = true;
    const load = async () => {
      try {
        const rows = await db.getMessages();
        if (active) setMessages(rows);
      } catch (e) {
        console.error("Failed to load messages", e);
      }
    };
    load();

    const channel = sb
      .channel("messages-stream")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "messages" },
        () => load(),
      )
      .subscribe();

    return () => {
      active = false;
      sb.removeChannel(channel);
    };
  }, [enabled]);

  return { messages, refresh: () => db.getMessages().then(setMessages) };
}

/** Live list of orders (admin only). */
export function useOrders(enabled: boolean) {
  const [orders, setOrders] = useState<OrderRecord[]>([]);

  useEffect(() => {
    if (!enabled) return;
    let active = true;
    const load = async () => {
      try {
        const rows = await db.getOrders();
        if (active) setOrders(rows);
      } catch (e) {
        console.error("Failed to load orders", e);
      }
    };
    load();

    const channel = sb
      .channel("orders-stream")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "orders" },
        () => load(),
      )
      .subscribe();

    return () => {
      active = false;
      sb.removeChannel(channel);
    };
  }, [enabled]);

  return { orders, refresh: () => db.getOrders().then(setOrders) };
}