import { useSyncExternalStore } from "react";

export interface CartItem {
  productId: string;
  name: string;
  image: string;
  price: number;
  quantity: number;
  unit: string; // resolved unit label: հատ / մ / լ
}

const STORAGE_KEY = "sosshin_cart_v1";

function loadInitial(): CartItem[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.sessionStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

let items: CartItem[] = loadInitial();
const listeners = new Set<() => void>();
const EMPTY: CartItem[] = [];

function persist() {
  if (typeof window !== "undefined") {
    try {
      window.sessionStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    } catch {
      /* ignore quota */
    }
  }
  listeners.forEach((l) => l());
}

/** Resolve the unit label from product name / unit string. */
export function resolveUnit(name: string, unit?: string): string {
  const hay = `${name} ${unit ?? ""}`.toLowerCase();
  if (hay.includes("/մ")) return "մ";
  if (hay.includes("/լ")) return "լ";
  return "հատ";
}

export const cart = {
  getItems: () => items,
  add(item: Omit<CartItem, "quantity">, qty = 1) {
    const existing = items.find((i) => i.productId === item.productId);
    if (existing) {
      items = items.map((i) =>
        i.productId === item.productId
          ? { ...i, quantity: i.quantity + qty }
          : i,
      );
    } else {
      items = [...items, { ...item, quantity: qty }];
    }
    persist();
  },
  setQuantity(productId: string, qty: number) {
    const q = Math.max(1, Math.min(9999, Math.round(qty)));
    items = items.map((i) => (i.productId === productId ? { ...i, quantity: q } : i));
    persist();
  },
  remove(productId: string) {
    items = items.filter((i) => i.productId !== productId);
    persist();
  },
  clear() {
    items = [];
    persist();
  },
  total: () => items.reduce((sum, i) => sum + i.price * i.quantity, 0),
  count: () => items.reduce((sum, i) => sum + i.quantity, 0),
};

function subscribe(cb: () => void) {
  listeners.add(cb);
  return () => listeners.delete(cb);
}

export function useCart() {
  const snapshot = useSyncExternalStore(
    subscribe,
    () => items,
    () => EMPTY,
  );
  const total = snapshot.reduce((sum, i) => sum + i.price * i.quantity, 0);
  const count = snapshot.reduce((sum, i) => sum + i.quantity, 0);
  return { items: snapshot, total, count, cart };
}