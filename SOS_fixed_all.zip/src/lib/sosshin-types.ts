export interface Product {
  id: string;
  barcode: string;
  name: string;
  price: number;
  image: string;
  status?: string;
  pinned: boolean;
  createdAt: string;
  unit?: string;
}

export interface CustomerMessage {
  id: string;
  name: string;
  phone: string;
  email?: string;
  message: string;
  createdAt: string;
}

export interface AdminUser {
  email: string;
  role: string;
}