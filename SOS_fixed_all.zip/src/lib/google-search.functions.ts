import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const Input = z.object({
  query: z.string().trim().min(2).max(120),
});

export interface ImageSearchResult {
  title: string;
  imageUrl: string;
  thumbnail: string;
  contextLink: string;
}

export type ImageSearchResponse =
  | { configured: false; results: [] }
  | { configured: true; results: ImageSearchResult[] };

async function assertAdmin(context: any) {
  const { data: isAdmin } = await context.supabase.rpc("has_role", {
    _user_id: context.userId,
    _role: "admin",
  });
  const { data: isMain } = await context.supabase.rpc("has_role", {
    _user_id: context.userId,
    _role: "main_admin",
  });
  if (!isAdmin && !isMain) throw new Response("Forbidden", { status: 403 });
}

/**
 * Search Google (Custom Search API, image mode) for product images.
 * Returns { configured: false } when API keys are not set, so the UI can show
 * a clear message instead of crashing.
 */
export const searchProductImages = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => Input.parse(input))
  .handler(async ({ data, context }): Promise<ImageSearchResponse> => {
    await assertAdmin(context);

    const apiKey = process.env.GOOGLE_SEARCH_API_KEY;
    const cx = process.env.GOOGLE_SEARCH_ENGINE_ID;
    if (!apiKey || !cx) {
      return { configured: false, results: [] };
    }

    const safeQuery = data.query
      .replace(/[\r\n\t]+/g, " ")
      .replace(/\s{2,}/g, " ")
      .trim()
      .slice(0, 120);

    const url = new URL("https://www.googleapis.com/customsearch/v1");
    url.searchParams.set("key", apiKey);
    url.searchParams.set("cx", cx);
    url.searchParams.set("q", safeQuery);
    url.searchParams.set("searchType", "image");
    url.searchParams.set("num", "8");
    url.searchParams.set("safe", "active");

    try {
      const res = await fetch(url.toString());
      if (!res.ok) {
        console.error("[google-search] failed", res.status, await res.text());
        return { configured: true, results: [] };
      }
      const json: any = await res.json();
      const results: ImageSearchResult[] = (json.items ?? [])
        .filter((it: any) => it?.link)
        .map((it: any) => ({
          title: String(it.title ?? "").slice(0, 200),
          imageUrl: String(it.link),
          thumbnail: String(it.image?.thumbnailLink ?? it.link),
          contextLink: String(it.image?.contextLink ?? ""),
        }));
      return { configured: true, results };
    } catch (err) {
      console.error("[google-search] threw", err);
      return { configured: true, results: [] };
    }
  });