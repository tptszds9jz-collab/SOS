import { formatPrice } from "./utils";
import { STATUS_LABELS_HY, type OrderRecord } from "./order-types";

const ADMIN_EMAIL = "sosshin.am@gmail.com";
const SHOP_PHONE = "+374 95 506 677";

function escapeHtml(str: string): string {
  return String(str ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function createRawEmail(to: string, subject: string, html: string): string {
  const encodedSubject = `=?UTF-8?B?${Buffer.from(subject, "utf-8").toString("base64")}?=`;
  const message = [
    `To: ${to}`,
    `Subject: ${encodedSubject}`,
    "MIME-Version: 1.0",
    'Content-Type: text/html; charset="UTF-8"',
    "Content-Transfer-Encoding: base64",
    "",
    Buffer.from(html, "utf-8").toString("base64"),
  ].join("\r\n");
  return Buffer.from(message, "utf-8")
    .toString("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");
}

/** Send one email via the connected Gmail account. Never throws. */
async function sendGmail(to: string, subject: string, html: string): Promise<boolean> {
  try {
    const lovableApiKey = process.env.LOVABLE_API_KEY;
    const gmailKey = process.env.GOOGLE_MAIL_API_KEY;
    if (!lovableApiKey || !gmailKey) {
      console.error("[order-email] Missing LOVABLE_API_KEY or GOOGLE_MAIL_API_KEY");
      return false;
    }
    const raw = createRawEmail(to, subject, html);
    const res = await fetch(
      "https://connector-gateway.lovable.dev/google_mail/gmail/v1/users/me/messages/send",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${lovableApiKey}`,
          "X-Connection-Api-Key": gmailKey,
        },
        body: JSON.stringify({ raw }),
      },
    );
    if (!res.ok) {
      console.error("[order-email] Gmail send failed", res.status, await res.text());
      return false;
    }
    return true;
  } catch (err) {
    console.error("[order-email] send threw", err);
    return false;
  }
}

function trackingLink(order: OrderRecord, origin: string): string {
  const base = origin.replace(/\/$/, "");
  return `${base}/track-order?code=${encodeURIComponent(order.orderCode)}`;
}

function itemsTableHtml(order: OrderRecord): string {
  const rows = order.items
    .map(
      (i) => `
      <tr>
        <td style="padding:6px 10px;border:1px solid #e2e2e2;">${escapeHtml(i.name)}</td>
        <td style="padding:6px 10px;border:1px solid #e2e2e2;text-align:center;">${i.quantity} ${escapeHtml(i.unit)}</td>
        <td style="padding:6px 10px;border:1px solid #e2e2e2;text-align:right;">${formatPrice(i.price)}</td>
        <td style="padding:6px 10px;border:1px solid #e2e2e2;text-align:right;">${formatPrice(i.subtotal)}</td>
      </tr>`,
    )
    .join("");
  return `
    <table style="border-collapse:collapse;width:100%;font-size:14px;margin:12px 0;">
      <thead>
        <tr style="background:#f4f4f5;">
          <th style="padding:6px 10px;border:1px solid #e2e2e2;text-align:left;">Ապրանք</th>
          <th style="padding:6px 10px;border:1px solid #e2e2e2;">Քանակ</th>
          <th style="padding:6px 10px;border:1px solid #e2e2e2;text-align:right;">Գին</th>
          <th style="padding:6px 10px;border:1px solid #e2e2e2;text-align:right;">Ընդամենը</th>
        </tr>
      </thead>
      <tbody>${rows}</tbody>
    </table>`;
}

export async function sendNewOrderAdminEmail(order: OrderRecord, origin: string): Promise<boolean> {
  const link = trackingLink(order, origin);
  const subject = `Նոր պատվեր SOS կայքում — ${order.orderCode}`;
  const html = `
    <div style="font-family:Arial,sans-serif;line-height:1.6;color:#1a1a1a;">
      <h2>Նոր պատվեր — ${escapeHtml(order.orderCode)}</h2>
      <p><strong>Ստուգման էջ՝</strong> <a href="${link}">${escapeHtml(link)}</a></p>
      <p>
        <strong>Անուն՝</strong> ${escapeHtml(order.customerName)}<br/>
        <strong>Հեռախոս՝</strong> ${escapeHtml(order.customerPhone)}<br/>
        ${order.customerEmail ? `<strong>Էլ. հասցե՝</strong> ${escapeHtml(order.customerEmail)}<br/>` : ""}
        <strong>Առաքման եղանակ՝</strong> ${escapeHtml(order.deliveryMethod)}<br/>
        ${order.address ? `<strong>Հասցե՝</strong> ${escapeHtml(order.address)}<br/>` : ""}
        ${order.comment ? `<strong>Մեկնաբանություն՝</strong> ${escapeHtml(order.comment)}<br/>` : ""}
        <strong>Կարգավիճակ՝</strong> ${escapeHtml(STATUS_LABELS_HY[order.status])}<br/>
        <strong>Ամսաթիվ՝</strong> ${escapeHtml(new Date(order.createdAt).toLocaleString("hy-AM"))}
      </p>
      ${itemsTableHtml(order)}
      <p style="font-size:16px;"><strong>Ընդհանուր գումար՝ ${formatPrice(order.totalAmount)}</strong></p>
    </div>`;
  return sendGmail(ADMIN_EMAIL, subject, html);
}

export async function sendNewOrderCustomerEmail(order: OrderRecord, origin: string): Promise<boolean> {
  if (!order.customerEmail) return false;
  const link = trackingLink(order, origin);
  const subject = `Ձեր SOS պատվերն ընդունվել է — ${order.orderCode}`;
  const html = `
    <div style="font-family:Arial,sans-serif;line-height:1.6;color:#1a1a1a;">
      <p>Սիրելի՛ ${escapeHtml(order.customerName)},</p>
      <p>Ձեր պատվերն ընդունվել է։</p>
      <p><strong>Պատվերի ստուգման կոդը՝ ${escapeHtml(order.orderCode)}</strong></p>
      <p>Դուք կարող եք հետևել պատվերի կարգավիճակին այս հղումով՝<br/>
      <a href="${link}">${escapeHtml(link)}</a></p>
      <p>Մեր թիմը շուտով կկապվի Ձեզ հետ՝ պատվերի մանրամասները, վճարման ձևը և առաքման պայմանները ճշտելու համար։</p>
      <p>Եթե հարցը շտապ է, կարող եք զանգահարել՝ ${SHOP_PHONE}։</p>
      <p>Շնորհակալություն վստահության համար։<br/>SOS</p>
    </div>`;
  return sendGmail(order.customerEmail, subject, html);
}

export async function sendOrderConfirmedEmail(order: OrderRecord, origin: string): Promise<boolean> {
  if (!order.customerEmail) return false;
  const link = trackingLink(order, origin);
  const subject = `Ձեր SOS պատվերը հաստատվել է — ${order.orderCode}`;
  const html = `
    <div style="font-family:Arial,sans-serif;line-height:1.6;color:#1a1a1a;">
      <p>Սիրելի՛ ${escapeHtml(order.customerName)},</p>
      <p>Ձեր պատվերը հաստատվել է։ Մեր թիմը շուտով կկապվի Ձեզ հետ՝ պատվերի մանրամասները, վճարման ձևը և առաքման պայմանները ճշտելու համար։</p>
      <p><strong>Պատվերի ստուգման կոդը՝ ${escapeHtml(order.orderCode)}</strong><br/>
      Ստուգման հղում՝ <a href="${link}">${escapeHtml(link)}</a></p>
      <p>Շնորհակալություն վստահության համար։<br/>SOS</p>
    </div>`;
  return sendGmail(order.customerEmail, subject, html);
}

export async function sendOrderCancelledEmail(order: OrderRecord, origin: string): Promise<boolean> {
  if (!order.customerEmail) return false;
  const link = trackingLink(order, origin);
  const subject = `Ձեր SOS պատվերը չեղարկվել է — ${order.orderCode}`;
  const html = `
    <div style="font-family:Arial,sans-serif;line-height:1.6;color:#1a1a1a;">
      <p>Սիրելի՛ ${escapeHtml(order.customerName)},</p>
      <p>Ձեր պատվերը չեղարկվել է։</p>
      <p><strong>Պատվերի ստուգման կոդը՝ ${escapeHtml(order.orderCode)}</strong><br/>
      Ստուգման հղում՝ <a href="${link}">${escapeHtml(link)}</a></p>
      <p>Մանրամասների համար կարող եք կապ հաստատել մեզ հետ՝ ${SHOP_PHONE}։</p>
      <p>SOS</p>
    </div>`;
  return sendGmail(order.customerEmail, subject, html);
}