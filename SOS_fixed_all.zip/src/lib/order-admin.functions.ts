import { createServerFn } from "@tanstack/react-start";
import { getRequestUrl } from "@tanstack/react-start/server";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";
import type { OrderRecord, OrderStatus } from "./order-types";
import { ORDER_STATUSES } from "./order-types";

const FALLBACK_ORIGIN = "https://kesoyanvardan.lovable.app";

const Input = z.object({
  orderId: z.string().uuid(),
  status: z.enum(["New", "Processing", "Confirmed", "Delivered", "Cancelled"]),
});

function getOrigin(): string {
  try {
    const url = getRequestUrl();
    if (url) return new URL(url).origin;
  } catch {
    /* ignore */
  }
  return process.env.SITE_URL || FALLBACK_ORIGIN;
}

export const updateOrderStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => Input.parse(input))
  .handler(async ({ data, context }) => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    const { data: isMain } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "main_admin",
    });
    if (!isAdmin && !isMain) {
      throw new Response("Forbidden", { status: 403 });
    }

    if (!ORDER_STATUSES.includes(data.status as OrderStatus)) {
      throw new Response("Invalid status", { status: 400 });
    }

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: updated, error } = await supabaseAdmin
      .from("orders")
      .update({ status: data.status })
      .eq("id", data.orderId)
      .select()
      .single();
    if (error || !updated) throw new Error("Failed to update order");

    // Send status emails only for Confirmed / Cancelled and only if email exists.
    if ((data.status === "Confirmed" || data.status === "Cancelled") && updated.customer_email) {
      try {
        const { data: items } = await supabaseAdmin
          .from("order_items")
          .select("product_id, name, image, price, quantity, unit, subtotal")
          .eq("order_id", updated.id);

        const record: OrderRecord = {
          id: updated.id,
          orderCode: updated.order_code,
          customerName: updated.customer_name,
          customerPhone: updated.customer_phone,
          customerEmail: updated.customer_email,
          deliveryMethod: updated.delivery_method,
          address: updated.address,
          comment: updated.comment,
          totalAmount: Number(updated.total_amount) || 0,
          status: updated.status as OrderStatus,
          createdAt: updated.created_at,
          items: (items ?? []).map((i: any) => ({
            productId: i.product_id,
            name: i.name,
            image: i.image,
            price: Number(i.price) || 0,
            quantity: Number(i.quantity) || 0,
            unit: i.unit,
            subtotal: Number(i.subtotal) || 0,
          })),
        };
        const origin = getOrigin();
        const emails = await import("./order-emails.server");
        if (data.status === "Confirmed") await emails.sendOrderConfirmedEmail(record, origin);
        else await emails.sendOrderCancelledEmail(record, origin);
      } catch (err) {
        console.error("[updateOrderStatus] email error", err);
      }
    }

    return { ok: true as const, status: data.status };
  });