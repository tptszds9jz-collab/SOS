// Hero image stored on the Lovable CDN (uploaded from the original project).
export const HERO_IMAGE =
  "/__l5e/assets-v1/3d6a4738-21a6-4e6c-8d49-b9a0f8602151/pool-hero.jpg";
