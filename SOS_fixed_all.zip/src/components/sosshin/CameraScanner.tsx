import React, { useEffect, useRef, useState } from "react";
import { BrowserMultiFormatReader, type IScannerControls } from "@zxing/browser";
import { X, Camera, Barcode as BarcodeIcon } from "lucide-react";

interface Props {
  onBarcode: (code: string) => void;
  onPhoto: (dataUrl: string) => void;
  onClose: () => void;
}

type Mode = "barcode" | "photo";

export default function CameraScanner({ onBarcode, onPhoto, onClose }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const controlsRef = useRef<IScannerControls | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [mode, setMode] = useState<Mode>("barcode");
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;

    const stop = () => {
      try {
        controlsRef.current?.stop();
      } catch {
        /* ignore */
      }
      controlsRef.current = null;
      streamRef.current?.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    };

    const start = async () => {
      setError("");
      try {
        if (mode === "barcode") {
          const reader = new BrowserMultiFormatReader();
          const controls = await reader.decodeFromVideoDevice(
            undefined,
            videoRef.current!,
            (result) => {
              if (result && !cancelled) {
                onBarcode(result.getText());
                stop();
              }
            },
          );
          if (cancelled) {
            controls.stop();
            return;
          }
          controlsRef.current = controls;
        } else {
          const stream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: "environment" },
          });
          if (cancelled) {
            stream.getTracks().forEach((t) => t.stop());
            return;
          }
          streamRef.current = stream;
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
            await videoRef.current.play().catch(() => {});
          }
        }
      } catch (e) {
        console.error(e);
        setError("Չհաջողվեց բացել տեսախցիկը։ Ստուգեք թույլտվությունները։");
      }
    };

    start();
    return () => {
      cancelled = true;
      stop();
    };
  }, [mode, onBarcode]);

  const capturePhoto = () => {
    const video = videoRef.current;
    if (!video) return;
    const canvas = document.createElement("canvas");
    const w = video.videoWidth || 640;
    const h = video.videoHeight || 480;
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, w, h);
    const dataUrl = canvas.toDataURL("image/jpeg", 0.8);
    onPhoto(dataUrl);
  };

  return (
    <div className="fixed inset-0 z-[100] flex flex-col bg-black/95">
      <div className="flex items-center justify-between p-4 text-white">
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => setMode("barcode")}
            className={`flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-bold ${mode === "barcode" ? "bg-accent text-white" : "bg-white/10"}`}
          >
            <BarcodeIcon className="h-4 w-4" /> Barcode
          </button>
          <button
            type="button"
            onClick={() => setMode("photo")}
            className={`flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-bold ${mode === "photo" ? "bg-accent text-white" : "bg-white/10"}`}
          >
            <Camera className="h-4 w-4" /> Լուսանկար
          </button>
        </div>
        <button type="button" onClick={onClose} className="rounded-lg bg-white/10 p-2">
          <X className="h-6 w-6 text-white" />
        </button>
      </div>

      <div className="relative flex flex-1 items-center justify-center overflow-hidden">
        <video ref={videoRef} className="max-h-full max-w-full" muted playsInline />
        {mode === "barcode" && (
          <div className="pointer-events-none absolute inset-x-12 top-1/2 h-32 -translate-y-1/2 rounded-xl border-2 border-accent/80" />
        )}
      </div>

      <div className="p-6 text-center text-white">
        {error ? (
          <p className="text-red-400 font-bold">{error}</p>
        ) : mode === "barcode" ? (
          <p className="text-sm text-white/70">Ուղղեք տեսախցիկը դեպի barcode-ը...</p>
        ) : (
          <button
            type="button"
            onClick={capturePhoto}
            className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-accent ring-4 ring-white/30"
          >
            <Camera className="h-7 w-7 text-white" />
          </button>
        )}
      </div>
    </div>
  );
}