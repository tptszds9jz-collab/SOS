import React, { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { trackOrder } from "@/lib/orders.functions";
import { formatPrice } from "@/lib/utils";
import { Search, ArrowLeft, Package } from "lucide-react";

type TrackResult = Awaited<ReturnType<typeof trackOrder>>;

export default function TrackOrderPage() {
  const track = useServerFn(trackOrder);
  const [code, setCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState<TrackResult | null>(null);

  const lookup = async (value: string) => {
    const c = value.trim();
    if (!/^\d{4}$/.test(c)) {
      setError("Մուտքագրեք 4-նիշանոց կոդ։");
      return;
    }
    setError("");
    setLoading(true);
    setResult(null);
    try {
      const res = await track({ data: { code: c } });
      setResult(res);
      if (!res.found) setError("Այս կոդով պատվեր չգտնվեց։");
    } catch (e) {
      console.error(e);
      setError("Որոնումը ձախողվեց։ Փորձեք կրկին։");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (typeof window === "undefined") return;
    const params = new URLSearchParams(window.location.search);
    const c = params.get("code");
    if (c && /^\d{4}$/.test(c)) {
      setCode(c);
      lookup(c);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="sosshin min-h-screen bg-bg-main font-sans text-text-secondary">
      <header className="flex items-center justify-between border-b border-border px-6 py-4 md:px-16">
        <a href="/" className="flex items-center gap-3">
          <div className="flex h-10 min-w-[54px] items-center justify-center rounded-lg bg-accent font-extrabold text-white">SOS</div>
          <span className="hidden text-sm font-extrabold text-text-muted sm:block">sosshin.am</span>
        </a>
        <a href="/" className="flex items-center gap-2 text-sm font-bold text-text-secondary hover:text-white">
          <ArrowLeft className="h-4 w-4" /> Գլխավոր
        </a>
      </header>

      <main className="mx-auto max-w-2xl px-6 py-16">
        <p className="eyebrow mb-3">Order tracking</p>
        <h1 className="mb-3 text-3xl font-extrabold text-white md:text-5xl">Հետևել պատվերին</h1>
        <p className="mb-8 text-text-muted">Մուտքագրեք Ձեր պատվերի 4-նիշանոց ստուգման կոդը։</p>

        <form
          onSubmit={(e) => { e.preventDefault(); lookup(code); }}
          className="flex flex-col gap-3 sm:flex-row"
        >
          <input
            inputMode="numeric"
            maxLength={4}
            value={code}
            onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 4))}
            placeholder="Օրինակ՝ 0326"
            className="w-full text-center text-2xl tracking-[0.5em] font-extrabold"
          />
          <button
            type="submit"
            disabled={loading}
            className="flex h-14 shrink-0 items-center justify-center gap-2 rounded-lg bg-accent px-8 font-extrabold text-white hover:bg-accent-hover disabled:opacity-60"
          >
            <Search className="h-5 w-5" /> {loading ? "Փնտրում է..." : "Ստուգել"}
          </button>
        </form>

        {error && <p className="mt-4 font-bold text-red-400">{error}</p>}

        {result?.found && (
          <div className="mt-10 grid gap-6 rounded-xl border border-border bg-bg-card p-6 shadow-2xl">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="text-xs uppercase text-text-muted">Պատվերի կոդ</p>
                <p className="text-2xl font-extrabold tracking-widest text-white">{result.orderCode}</p>
              </div>
              <span className="rounded-full border border-accent/40 bg-accent/10 px-4 py-2 text-sm font-extrabold text-accent">
                {result.statusLabel}
              </span>
            </div>
            <p className="rounded-lg bg-bg-sidebar p-3 text-sm text-text-muted">{result.statusExplain}</p>

            <div>
              <p className="mb-3 flex items-center gap-2 text-sm font-extrabold text-white"><Package className="h-4 w-4" /> Ապրանքներ</p>
              <div className="grid gap-2">
                {result.items.map((i, idx) => (
                  <div key={idx} className="flex items-center justify-between rounded-lg border border-border bg-bg-sidebar p-3 text-sm">
                    <span className="text-white">{i.name}</span>
                    <span className="text-text-muted">{i.quantity} {i.unit} × {formatPrice(i.price)} = <strong className="text-white">{formatPrice(i.subtotal)}</strong></span>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between border-t border-border pt-4">
              <span className="text-text-muted">Ընդհանուր գումար</span>
              <span className="text-xl font-extrabold text-white">{formatPrice(result.totalAmount)}</span>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}