import React, { useState } from "react";
import { ShoppingCart, X, Plus, Minus, Trash2, CheckCircle, Copy } from "lucide-react";
import { useCart } from "@/lib/cart-store";
import { createOrder } from "@/lib/orders.functions";
import { formatPrice } from "@/lib/utils";

type View = "cart" | "checkout" | "success";

interface SuccessInfo {
  orderCode: string;
  trackingPath: string;
}

export default function CartSystem() {
  const { items, total, count, cart } = useCart();
  const [open, setOpen] = useState(false);
  const [view, setView] = useState<View>("cart");
  const [delivery, setDelivery] = useState<"delivery" | "pickup">("delivery");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState<SuccessInfo | null>(null);
  const [copied, setCopied] = useState(false);

  const openCart = () => {
    setView(success ? "success" : "cart");
    setOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError("");
    const fd = new FormData(e.currentTarget);
    const payload = {
      name: String(fd.get("name") || "").trim(),
      phone: String(fd.get("phone") || "").trim(),
      email: String(fd.get("email") || "").trim(),
      deliveryMethod: delivery,
      address: String(fd.get("address") || "").trim(),
      comment: String(fd.get("comment") || "").trim(),
      items: items.map((i) => ({ productId: i.productId, quantity: i.quantity })),
    };
    if (!payload.name || !payload.phone) {
      setError("Անունը և հեռախոսը պարտադիր են։");
      return;
    }
    if (delivery === "delivery" && !payload.address) {
      setError("Առաքման համար անհրաժեշտ է հասցե։");
      return;
    }
    setSubmitting(true);
    try {
      const res = await createOrder({ data: payload });
      setSuccess(res);
      setView("success");
      cart.clear();
    } catch (err) {
      console.error(err);
      setError("Պատվերը չհաջողվեց ուղարկել։ Փորձեք կրկին։");
    } finally {
      setSubmitting(false);
    }
  };

  const trackingUrl =
    success && typeof window !== "undefined"
      ? `${window.location.origin}${success.trackingPath}`
      : success?.trackingPath ?? "";

  const copyLink = () => {
    if (!trackingUrl) return;
    navigator.clipboard?.writeText(trackingUrl).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <>
      <button
        onClick={openCart}
        className="fixed bottom-6 right-6 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-accent text-white shadow-lg shadow-accent/30 hover:bg-accent-hover transition-colors"
        aria-label="Զամբյուղ"
      >
        <ShoppingCart className="h-6 w-6" />
        {count > 0 && (
          <span className="absolute -top-1 -right-1 flex h-6 min-w-[24px] items-center justify-center rounded-full bg-amber-500 px-1.5 text-xs font-extrabold text-white">
            {count}
          </span>
        )}
      </button>

      {open && (
        <div className="fixed inset-0 z-[90] flex justify-end">
          <div className="absolute inset-0 bg-black/60" onClick={() => setOpen(false)} />
          <div className="relative flex h-full w-full max-w-md flex-col bg-bg-card text-text-secondary shadow-2xl">
            <div className="flex items-center justify-between border-b border-border p-5">
              <h3 className="text-lg font-extrabold text-white">
                {view === "cart" && "Զամբյուղ"}
                {view === "checkout" && "Պատվերի ձևակերպում"}
                {view === "success" && "Պատվերն ընդունվեց"}
              </h3>
              <button onClick={() => setOpen(false)} className="rounded-lg border border-border p-2">
                <X className="h-5 w-5 text-white" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-5">
              {view === "cart" && (
                <>
                  {items.length === 0 ? (
                    <p className="mt-10 text-center text-text-muted">Զամբյուղը դատարկ է։</p>
                  ) : (
                    <div className="grid gap-4">
                      {items.map((i) => (
                        <div key={i.productId} className="flex gap-3 rounded-lg border border-border bg-bg-sidebar p-3">
                          <img src={i.image} alt={i.name} className="h-16 w-16 shrink-0 rounded-md object-cover bg-bg-main" />
                          <div className="flex flex-1 flex-col gap-1">
                            <strong className="text-sm text-white">{i.name}</strong>
                            <span className="text-xs text-text-muted">{formatPrice(i.price)} / {i.unit}</span>
                            <div className="mt-1 flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <button onClick={() => cart.setQuantity(i.productId, i.quantity - 1)} className="rounded border border-border p-1"><Minus className="h-3 w-3 text-white" /></button>
                                <span className="min-w-[2rem] text-center text-sm font-bold text-white">{i.quantity} {i.unit}</span>
                                <button onClick={() => cart.setQuantity(i.productId, i.quantity + 1)} className="rounded border border-border p-1"><Plus className="h-3 w-3 text-white" /></button>
                              </div>
                              <button onClick={() => cart.remove(i.productId)} className="text-red-400 hover:text-red-300"><Trash2 className="h-4 w-4" /></button>
                            </div>
                            <span className="text-right text-sm font-extrabold text-white">{formatPrice(i.price * i.quantity)}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </>
              )}

              {view === "checkout" && (
                <form id="checkout-form" onSubmit={handleSubmit} className="grid gap-4">
                  <label className="flex flex-col gap-1.5 text-sm font-bold text-white">
                    Անուն *
                    <input name="name" required placeholder="Ձեր անունը" />
                  </label>
                  <label className="flex flex-col gap-1.5 text-sm font-bold text-white">
                    Հեռախոս *
                    <input name="phone" type="tel" required placeholder="+374" />
                  </label>
                  <label className="flex flex-col gap-1.5 text-sm font-bold text-white">
                    Էլ. հասցե (ոչ պարտադիր)
                    <input name="email" type="email" placeholder="you@example.com" />
                  </label>
                  <div className="flex flex-col gap-2 text-sm font-bold text-white">
                    Առաքման եղանակ *
                    <div className="flex gap-2">
                      <button type="button" onClick={() => setDelivery("delivery")} className={`flex-1 rounded-lg border px-3 py-2 text-sm ${delivery === "delivery" ? "border-accent bg-accent/10 text-white" : "border-border text-text-muted"}`}>Առաքում հասցեով</button>
                      <button type="button" onClick={() => setDelivery("pickup")} className={`flex-1 rounded-lg border px-3 py-2 text-sm ${delivery === "pickup" ? "border-accent bg-accent/10 text-white" : "border-border text-text-muted"}`}>Վերցնել խանութից</button>
                    </div>
                  </div>
                  {delivery === "delivery" && (
                    <label className="flex flex-col gap-1.5 text-sm font-bold text-white">
                      Հասցե *
                      <input name="address" required placeholder="Քաղաք, փողոց, շենք" />
                    </label>
                  )}
                  {delivery === "delivery" && (
                    <p className="rounded-lg bg-bg-sidebar p-3 text-xs text-text-muted">Առաքման արժեքը և ժամկետները ճշտվում են պատվերի հաստատման ժամանակ։</p>
                  )}
                  <label className="flex flex-col gap-1.5 text-sm font-bold text-white">
                    Մեկնաբանություն (ոչ պարտադիր)
                    <textarea name="comment" rows={3} placeholder="Լրացուցիչ տեղեկություն" />
                  </label>
                  <p className="rounded-lg bg-bg-sidebar p-3 text-xs text-text-muted">Վճարման ձևը և վերջնական պայմանները ճշտվում են պատվերի հաստատման ժամանակ մեր աշխատակցի զանգով։</p>
                  {error && <p className="text-sm font-bold text-red-400">{error}</p>}
                </form>
              )}

              {view === "success" && success && (
                <div className="grid gap-4 pt-6 text-center">
                  <CheckCircle className="mx-auto h-14 w-14 text-emerald-500" />
                  <p className="text-white">Ձեր պատվերն ընդունվել է։</p>
                  <div className="rounded-xl border border-border bg-bg-sidebar p-4">
                    <p className="text-xs text-text-muted">Պատվերի ստուգման կոդը</p>
                    <p className="text-3xl font-extrabold tracking-widest text-white">{success.orderCode}</p>
                  </div>
                  <p className="text-sm text-text-muted">Հետևեք պատվերի կարգավիճակին այս հղումով՝</p>
                  <div className="flex items-center gap-2">
                    <a href={success.trackingPath} className="flex-1 truncate rounded-lg border border-border bg-bg-sidebar px-3 py-2 text-left text-xs text-accent">{trackingUrl}</a>
                    <button onClick={copyLink} className="rounded-lg border border-border p-2"><Copy className="h-4 w-4 text-white" /></button>
                  </div>
                  {copied && <p className="text-xs text-emerald-500">Պատճենվեց!</p>}
                  <a href={success.trackingPath} className="flex h-12 items-center justify-center rounded-lg bg-accent font-extrabold text-white hover:bg-accent-hover">Հետևել պատվերին</a>
                </div>
              )}
            </div>

            {view === "cart" && items.length > 0 && (
              <div className="border-t border-border p-5">
                <div className="mb-4 flex items-center justify-between">
                  <span className="text-text-muted">Ընդհանուր</span>
                  <span className="text-xl font-extrabold text-white">{formatPrice(total)}</span>
                </div>
                <div className="flex gap-3">
                  <button onClick={() => setOpen(false)} className="flex-1 rounded-lg border border-border py-3 font-bold text-white">Շարունակել գնումները</button>
                  <button onClick={() => { setError(""); setView("checkout"); }} className="flex-1 rounded-lg bg-accent py-3 font-extrabold text-white hover:bg-accent-hover">Ձևակերպել</button>
                </div>
              </div>
            )}

            {view === "checkout" && (
              <div className="border-t border-border p-5">
                <div className="mb-4 flex items-center justify-between">
                  <span className="text-text-muted">Ընդհանուր</span>
                  <span className="text-xl font-extrabold text-white">{formatPrice(total)}</span>
                </div>
                <div className="flex gap-3">
                  <button type="button" onClick={() => setView("cart")} className="flex-1 rounded-lg border border-border py-3 font-bold text-white">Հետ</button>
                  <button type="submit" form="checkout-form" disabled={submitting} className="flex-1 rounded-lg bg-accent py-3 font-extrabold text-white hover:bg-accent-hover disabled:opacity-60">
                    {submitting ? "Ուղարկվում է..." : "Հաստատել պատվերը"}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}