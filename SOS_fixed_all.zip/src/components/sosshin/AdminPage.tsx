import React, { useEffect, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import type { Product, AdminUser } from "@/lib/sosshin-types";
import { cn, formatPrice } from "@/lib/utils";
import { useProducts, useMessages, useOrders, db } from "@/lib/sosshin-store";
import { adminSignOut } from "@/lib/sosshin-auth";
import { searchProducts, type ProductSuggestion } from "@/lib/product-search.functions";
import { searchProductImages, type ImageSearchResult } from "@/lib/google-search.functions";
import { identifyProductFromPhoto } from "@/lib/product-vision.functions";
import { updateOrderStatus } from "@/lib/order-admin.functions";
import { ORDER_STATUSES, STATUS_LABELS_HY, type OrderStatus } from "@/lib/order-types";
import CameraScanner from "./CameraScanner";
import {
  Plus, Package, MessageSquare, Users, Image as ImageIcon,
  Trash2, Edit2, Pin, LogOut, ChevronRight, Barcode, DollarSign,
  CheckCircle, Info, Cloud, ClipboardList, Camera,
} from "lucide-react";
import { HERO_IMAGE } from "@/lib/sosshin-assets";

const FALLBACK_IMAGE = HERO_IMAGE;

const LOCAL_SUGGESTIONS = [
  { name: "Լողավազանի նասոս 1.5 HP", barcode: "SOS-PUMP-1500", status: "Popular" },
  { name: "Լողավազանի նասոս 2 HP", barcode: "SOS-PUMP-2000", status: "New" },
  { name: "PVC խողովակ 50մմ", barcode: "SOS-PVC-50", status: "In Stock" },
  { name: "PVC անկյուն 90°", barcode: "SOS-PVC-ELBOW-90", status: "In Stock" },
  { name: "Ավազային ֆիլտր լողավազանի համար", barcode: "SOS-FILTER-SAND", status: "Sale" },
  { name: "Փական PVC 50մմ", barcode: "SOS-VALVE-50", status: "Popular" },
  { name: "Ճնշաչափ ֆիլտրի համար", barcode: "SOS-GAUGE-01", status: "New" },
];

export default function AdminPage() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<"products" | "orders" | "messages" | "admins">("products");
  const { products } = useProducts();
  const { messages } = useMessages(true);
  const { orders } = useOrders(true);
  const updateStatusFn = useServerFn(updateOrderStatus);
  const [admins, setAdmins] = useState<AdminUser[]>([]);
  const [editingProduct, setEditingProduct] = useState<Partial<Product> | null>(null);
  const [isSearchingOnline, setIsSearchingOnline] = useState(false);
  const [scanStatus, setScanStatus] = useState("");
  const [suggestions, setSuggestions] = useState<typeof LOCAL_SUGGESTIONS>([]);
  const [activeSuggestionField, setActiveSuggestionField] = useState<"name" | "barcode" | null>(null);
  const [aiQuery, setAiQuery] = useState("");
  const [aiResults, setAiResults] = useState<ProductSuggestion[]>([]);
  const [aiSearching, setAiSearching] = useState(false);
  const [aiError, setAiError] = useState("");
  const [scannerOpen, setScannerOpen] = useState(false);
  const [imgQuery, setImgQuery] = useState("");
  const [imgResults, setImgResults] = useState<ImageSearchResult[]>([]);
  const [imgSearching, setImgSearching] = useState(false);
  const [imgError, setImgError] = useState("");
  const [statusUpdating, setStatusUpdating] = useState<string | null>(null);

  const productSearchFn = useServerFn(searchProducts);
  const imageSearchFn = useServerFn(searchProductImages);
  const identifyFn = useServerFn(identifyProductFromPhoto);

  useEffect(() => {
    db.getAdmins().then(setAdmins).catch((e) => console.error(e));
  }, []);

  const handleLogout = async () => {
    await adminSignOut();
    navigate({ to: "/login" });
  };

  const handleNameChange = (val: string) => {
    setEditingProduct({ ...editingProduct, name: val });
    if (val.length > 1) {
      setSuggestions(LOCAL_SUGGESTIONS.filter((s) => s.name.toLowerCase().includes(val.toLowerCase())));
      setActiveSuggestionField("name");
    } else {
      setSuggestions([]);
      setActiveSuggestionField(null);
    }
  };

  const handleBarcodeChange = (val: string) => {
    setEditingProduct({ ...editingProduct, barcode: val });
    if (val.length > 1) {
      setSuggestions(
        LOCAL_SUGGESTIONS.filter(
          (s) =>
            s.name.toLowerCase().includes(val.toLowerCase()) ||
            s.barcode.toLowerCase().includes(val.toLowerCase()),
        ),
      );
      setActiveSuggestionField("barcode");
    } else {
      setSuggestions([]);
      setActiveSuggestionField(null);
    }
  };

  const applySuggestion = (s: (typeof LOCAL_SUGGESTIONS)[0]) => {
    setEditingProduct({ ...editingProduct, name: s.name, barcode: s.barcode, status: s.status });
    setSuggestions([]);
    setActiveSuggestionField(null);
  };

  const handleSaveProduct = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const productData: Product = {
      id: editingProduct?.id || crypto.randomUUID(),
      barcode: (formData.get("barcode") as string) || "",
      name: formData.get("name") as string,
      price: Number(formData.get("price")),
      image: editingProduct?.image || (formData.get("image") as string) || "",
      status: (formData.get("status") as string) || undefined,
      pinned: formData.get("pinned") === "on",
      createdAt: editingProduct?.createdAt || new Date().toISOString(),
      unit: (formData.get("unit") as string) || "",
    };
    try {
      await db.upsertProduct(productData);
      setEditingProduct(null);
      (e.target as HTMLFormElement).reset();
      setScanStatus("Ապրանքը հաջողությամբ պահպանվեց։");
    } catch (err) {
      console.error(err);
      setScanStatus("Պահպանումը ձախողվեց։");
    }
    setTimeout(() => setScanStatus(""), 3000);
  };

  const handleDeleteProduct = async (id: string) => {
    try {
      await db.deleteProduct(id);
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteMessage = async (id: string) => {
    try {
      await db.deleteMessage(id);
    } catch (err) {
      console.error(err);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        setScanStatus("Image too large (max 2MB)");
        return;
      }
      const reader = new FileReader();
      reader.onloadstart = () => setScanStatus("Սեղմում ենք նկարը...");
      reader.onloadend = () => {
        setEditingProduct({ ...editingProduct, image: reader.result as string });
        setScanStatus("Նկարը հաջողությամբ վերբեռնվեց։");
      };
      reader.readAsDataURL(file);
    }
  };

  const handleExportDB = () => {
    const data = { products, messages, exportedAt: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `sosshin-backup-${new Date().toISOString().split("T")[0]}.json`;
    a.click();
  };

  const handleSearchOnline = async () => {
    const barcode = editingProduct?.barcode;
    if (!barcode) {
      setScanStatus("Նախ լրացրեք կամ սկան արեք barcode-ը։");
      return;
    }
    setIsSearchingOnline(true);
    setScanStatus("Փնտրում է ինտերնետում...");
    try {
      const response = await fetch(
        `https://world.openfoodfacts.org/api/v2/product/${encodeURIComponent(barcode)}.json`,
      );
      const data = await response.json();
      if (data.product) {
        setEditingProduct({
          ...editingProduct,
          name: data.product.product_name || editingProduct?.name,
          image: data.product.image_front_url || editingProduct?.image,
        });
        setScanStatus("Գտավ տվյալներ։");
      } else {
        setScanStatus("Այս barcode-ով online արդյունք չգտնվեց։");
      }
    } catch (error) {
      setScanStatus("Online որոնումը չաշխատեց։");
    } finally {
      setIsSearchingOnline(false);
    }
  };

  const handleAiSearch = async () => {
    const query = aiQuery.trim();
    if (query.length < 2) {
      setAiError("Գրեք ապրանքի մոտավոր անունը (առնվազն 2 նիշ)։");
      return;
    }
    setAiSearching(true);
    setAiError("");
    setAiResults([]);
    try {
      const results = await productSearchFn({ data: { query } });
      if (!results.length) {
        setAiError("Արդյունք չգտնվեց։ Փորձեք այլ անուն։");
      }
      setAiResults(results);
    } catch (err) {
      console.error(err);
      setAiError("Google որոնումը ձախողվեց։ Ստուգեք API key / Engine ID կարգավորումները։");
    } finally {
      setAiSearching(false);
    }
  };

  const applyAiSuggestion = (s: ProductSuggestion) => {
    setEditingProduct({
      ...editingProduct,
      name: s.name,
      barcode: s.barcode,
      price: s.estimatedPrice,
      status: s.status,
    });
    setAiResults([]);
    setAiQuery("");
    setImgQuery(s.name);
    setScanStatus(`Ընտրվեց՝ ${s.name}։ Ստուգեք գինը/նկարը և պահպանեք։`);
    setTimeout(() => setScanStatus(""), 4000);
  };

  const handleImageSearch = async (queryOverride?: string) => {
    const query = (queryOverride ?? imgQuery).trim();
    if (query.length < 2) {
      setImgError("Գրեք ապրանքի անունը (առնվազն 2 նիշ)։");
      return;
    }
    setImgSearching(true);
    setImgError("");
    setImgResults([]);
    try {
      const res = await imageSearchFn({ data: { query } });
      if (!res.configured) {
        setImgError("Online product search is not configured. Please add search API key.");
        return;
      }
      if (!res.results.length) {
        setImgError("Նկարներ չգտնվեցին։ Փորձեք այլ անուն։");
      }
      setImgResults(res.results);
    } catch (err) {
      console.error(err);
      setImgError("Որոնումը ձախողվեց։ Փորձեք կրկին։");
    } finally {
      setImgSearching(false);
    }
  };

  const selectImage = (url: string) => {
    setEditingProduct((prev) => ({ ...prev, image: url }));
    setImgResults([]);
    setScanStatus("Նկարն ընտրվեց։ Ստուգեք և պահպանեք։");
    setTimeout(() => setScanStatus(""), 3000);
  };

  const onBarcodeScanned = (code: string) => {
    setScannerOpen(false);
    setEditingProduct((prev) => ({ ...prev, barcode: code }));
    setScanStatus(`Barcode սկանավորվեց՝ ${code}։`);
    setTimeout(() => setScanStatus(""), 3000);
  };

  const onPhotoCaptured = async (dataUrl: string) => {
    setScannerOpen(false);
    setScanStatus("Ճանաչում ենք ապրանքը նկարից...");
    try {
      const res = await identifyFn({ data: { image: dataUrl } });
      if (res.name) {
        setImgQuery(res.name);
        setEditingProduct((prev) => ({ ...prev, name: res.name }));
        setScanStatus(`Ճանաչվեց՝ ${res.name}։ Փնտրում ենք նկարներ...`);
        await handleImageSearch(res.name);
      } else {
        setScanStatus("Չհաջողվեց ճանաչել ապրանքը։ Գրեք անունը ձեռքով։");
      }
    } catch (err) {
      console.error(err);
      setScanStatus("Ճանաչումը ձախողվեց։");
    }
  };

  const handleStatusChange = async (orderId: string, status: OrderStatus) => {
    setStatusUpdating(orderId);
    try {
      await updateStatusFn({ data: { orderId, status } });
    } catch (err) {
      console.error("Failed to update status", err);
    } finally {
      setStatusUpdating(null);
    }
  };

  return (
    <div className="sosshin flex min-h-screen bg-bg-main font-sans text-text-secondary">
      <aside className="fixed inset-y-0 left-0 w-72 bg-bg-sidebar p-6 text-white overflow-y-auto z-40 hidden md:block border-r border-border">
        <div className="mb-10 flex items-center gap-4">
          <div className="flex h-12 min-w-[54px] items-center justify-center rounded-lg bg-accent font-extrabold text-white">
            SOS
          </div>
          <div>
            <strong className="block text-lg tracking-tight">sosshin.am</strong>
            <small className="font-semibold text-text-muted">Admin Dashboard</small>
          </div>
        </div>

        <nav className="grid gap-2">
          {(["products", "orders", "messages", "admins"] as const).map((tab) => {
            const Icon =
              tab === "products" ? Package
              : tab === "orders" ? ClipboardList
              : tab === "messages" ? MessageSquare
              : Users;
            const label =
              tab === "products" ? "Products"
              : tab === "orders" ? "Orders"
              : tab === "messages" ? "Messages"
              : "Admins";
            return (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={cn(
                  "flex w-full items-center gap-3 rounded-lg px-4 py-3 font-extrabold transition-all",
                  activeTab === tab ? "bg-bg-card text-white ring-1 ring-border" : "text-text-muted hover:text-white",
                )}
              >
                <Icon className="h-5 w-5" /> {label}
              </button>
            );
          })}
          <hr className="my-4 border-border" />
          <a href="/" className="flex w-full items-center gap-3 rounded-lg px-4 py-3 font-extrabold text-text-muted hover:text-white">
            Open site <ChevronRight className="h-4 w-4" />
          </a>
          <button
            onClick={handleLogout}
            className="flex w-full items-center gap-3 rounded-lg px-4 py-3 font-extrabold text-text-muted hover:text-white"
          >
            <LogOut className="h-5 w-5" /> Logout
          </button>

          <div className="mt-8 rounded-xl border border-border bg-white/5 p-4">
            <h4 className="mb-4 text-xs font-bold uppercase tracking-widest text-text-muted">Cloud & Backup</h4>
            <div className="grid gap-2">
              <div className="flex items-center gap-2 rounded-lg bg-green-500/10 p-2 border border-green-500/20">
                <Cloud className="h-4 w-4 text-green-500" />
                <div className="flex-1 overflow-hidden">
                  <p className="text-[10px] font-bold text-white truncate">Lovable Cloud</p>
                  <p className="text-[8px] text-text-muted">Live sync enabled</p>
                </div>
              </div>
              <button
                onClick={handleExportDB}
                className="flex w-full items-center justify-center gap-2 rounded-lg border border-border bg-transparent py-2 text-xs font-bold text-white hover:bg-white/5 transition-all"
              >
                Export JSON Backup
              </button>
            </div>
          </div>
        </nav>
      </aside>

      <main className="flex-1 md:ml-72 bg-bg-main pb-12">
        <header className="sticky top-0 z-30 flex h-16 items-center justify-between bg-bg-main/50 px-8 backdrop-blur-md border-b border-border text-white">
          <h2 className="text-xl font-bold tracking-tight">
            {activeTab === "products" && "Products"}
            {activeTab === "orders" && "Orders"}
            {activeTab === "messages" && "Messages"}
            {activeTab === "admins" && "Admins"}
          </h2>
          <div className="flex items-center gap-4">
            <div className="h-8 w-8 rounded-full bg-accent flex items-center justify-center text-white font-bold text-xs">SOS</div>
          </div>
        </header>

        <div className="px-8 pt-8">
          {activeTab === "products" && (
            <div className="grid gap-8">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <p className="eyebrow">Product management</p>
                  <h3 className="section-title text-2xl">Catalog</h3>
                </div>
                <div className="flex gap-4">
                  <div className="rounded-lg border border-border bg-bg-card px-4 py-2 shadow-sm">
                    <span className="text-xs font-bold text-text-muted uppercase">Total</span>
                    <p className="text-lg font-extrabold text-white">{products.length}</p>
                  </div>
                  <div className="rounded-lg border border-border bg-bg-card px-4 py-2 shadow-sm">
                    <span className="text-xs font-bold text-text-muted uppercase">Pinned</span>
                    <p className="text-lg font-extrabold text-white">{products.filter((p) => p.pinned).length}</p>
                  </div>
                </div>
              </div>

              <form onSubmit={handleSaveProduct} className="grid gap-6 rounded-xl border border-border bg-bg-card p-8 shadow-2xl">
                <div className="grid gap-3 rounded-lg border border-accent/40 bg-accent/5 p-5">
                  <div className="flex items-center gap-2">
                    <span className="eyebrow !text-accent">Google product finder</span>
                  </div>
                  <p className="text-xs text-text-muted">
                    Գրեք ապրանքի մոտավոր անունը, համակարգը Google Search-ից կառաջարկի համապատասխան ապրանքներ։ Ընտրեք ճիշտը՝ դաշտերն ինքնաշխատ լրացնելու համար։
                  </p>
                  <div className="flex flex-col gap-2 sm:flex-row">
                    <input
                      type="text"
                      value={aiQuery}
                      onChange={(e) => setAiQuery(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          e.preventDefault();
                          handleAiSearch();
                        }
                      }}
                      placeholder="Օրինակ՝ լողավազանի նասոս, PVC խողովակ..."
                      className="w-full"
                      autoComplete="off"
                    />
                    <button
                      type="button"
                      onClick={handleAiSearch}
                      disabled={aiSearching}
                      className="flex h-12 shrink-0 items-center justify-center rounded-lg bg-accent px-6 font-extrabold text-white shadow-lg shadow-accent/20 hover:bg-accent-hover transition-colors disabled:opacity-60"
                    >
                      {aiSearching ? "Փնտրում է..." : "Փնտրել"}
                    </button>
                  </div>
                  {aiError && <p className="text-xs font-bold text-red-400">{aiError}</p>}
                  {aiResults.length > 0 && (
                    <div className="grid gap-2">
                      {aiResults.map((s, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => applyAiSuggestion(s)}
                          className="flex flex-col gap-1 rounded-lg border border-border bg-bg-sidebar p-4 text-left hover:border-accent hover:bg-white/5 transition-colors"
                        >
                          <div className="flex items-center justify-between gap-3">
                            <strong className="text-sm text-white">{s.name}</strong>
                            <span className="shrink-0 text-xs font-extrabold text-accent">{formatPrice(s.estimatedPrice)}</span>
                          </div>
                          <span className="text-[0.7rem] text-text-muted">{s.barcode} • {s.status}</span>
                          {s.description && <span className="text-[0.7rem] text-text-muted">{s.description}</span>}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                <div className="grid gap-3 rounded-lg border border-border bg-bg-sidebar/50 p-5">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <span className="eyebrow">Search product online (Google)</span>
                    <button
                      type="button"
                      onClick={() => setScannerOpen(true)}
                      className="flex h-10 items-center gap-2 rounded-lg border border-border bg-white/5 px-4 text-sm font-extrabold text-white hover:bg-white/10 transition-colors"
                    >
                      <Camera className="h-4 w-4" /> Սկան տեսախցիկով
                    </button>
                  </div>
                  <p className="text-xs text-text-muted">
                    Գրեք ապրանքի մոտավոր անունը կամ սկան արեք, համակարգը ինտերնետից կառաջարկի նկարներ։ Ընտրեք ճիշտը՝ ապրանքի նկարը պահպանելու համար։
                  </p>
                  <div className="flex flex-col gap-2 sm:flex-row">
                    <input
                      type="text"
                      value={imgQuery}
                      onChange={(e) => setImgQuery(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          e.preventDefault();
                          handleImageSearch();
                        }
                      }}
                      placeholder="Օրինակ՝ pool filter, ջրի պոմպ, խողովակ 20մմ"
                      className="w-full"
                      autoComplete="off"
                    />
                    <button
                      type="button"
                      onClick={() => handleImageSearch()}
                      disabled={imgSearching}
                      className="flex h-12 shrink-0 items-center justify-center rounded-lg bg-accent px-6 font-extrabold text-white shadow-lg shadow-accent/20 hover:bg-accent-hover transition-colors disabled:opacity-60"
                    >
                      {imgSearching ? "Փնտրում է..." : "Փնտրել նկարներ"}
                    </button>
                  </div>
                  {imgError && <p className="text-xs font-bold text-amber-400">{imgError}</p>}
                  {imgResults.length > 0 && (
                    <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                      {imgResults.map((r, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => selectImage(r.imageUrl)}
                          title={r.title}
                          className="group relative aspect-square overflow-hidden rounded-lg border border-border bg-bg-main hover:border-accent transition-colors"
                        >
                          <img src={r.thumbnail} alt={r.title} className="h-full w-full object-cover" loading="lazy" />
                          <span className="absolute inset-x-0 bottom-0 bg-black/60 p-1 text-[0.6rem] text-white opacity-0 group-hover:opacity-100 transition-opacity">Ընտրել</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                <div className="grid gap-4 sm:grid-cols-[1fr_auto]">
                  <div className="flex flex-col gap-2 relative">
                    <label className="text-sm font-extrabold text-white">Barcode</label>
                    <div className="relative">
                      <Barcode className="absolute top-1/2 left-4 h-5 w-5 -translate-y-1/2 text-text-muted" />
                      <input
                        type="text"
                        name="barcode"
                        value={editingProduct?.barcode || ""}
                        onChange={(e) => handleBarcodeChange(e.target.value)}
                        placeholder="Սկան արեք կամ գրեք barcode"
                        className="w-full pl-12"
                        autoComplete="off"
                      />
                    </div>
                    {activeSuggestionField === "barcode" && suggestions.length > 0 && (
                      <div className="absolute top-full left-0 right-0 z-50 mt-1 max-h-48 overflow-y-auto rounded-lg border border-border bg-bg-sidebar shadow-2xl">
                        {suggestions.map((s, idx) => (
                          <button key={idx} type="button" onClick={() => applySuggestion(s)} className="flex w-full flex-col p-3 text-left hover:bg-white/5 border-b border-border last:border-0">
                            <strong className="text-sm text-white">{s.name}</strong>
                            <span className="text-[0.7rem] text-text-muted">{s.barcode} • {s.status}</span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                  <button type="button" onClick={handleSearchOnline} disabled={isSearchingOnline} className="self-end h-12 rounded-lg border border-border bg-transparent px-6 font-extrabold text-white hover:bg-white/5 transition-colors">
                    {isSearchingOnline ? "Searching..." : "Search online"}
                  </button>
                </div>
                {scanStatus && <p className="text-xs font-bold text-accent">{scanStatus}</p>}

                <div className="grid gap-6 sm:grid-cols-2">
                  <div className="flex flex-col gap-2 relative">
                    <label className="text-sm font-extrabold text-white">Product name</label>
                    <input
                      type="text"
                      name="name"
                      value={editingProduct?.name || ""}
                      onChange={(e) => handleNameChange(e.target.value)}
                      placeholder="Օրինակ՝ Pool Pump 1.5 HP"
                      required
                      autoComplete="off"
                      className="w-full"
                    />
                    {activeSuggestionField === "name" && suggestions.length > 0 && (
                      <div className="absolute top-full left-0 right-0 z-50 mt-1 max-h-48 overflow-y-auto rounded-lg border border-border bg-bg-sidebar shadow-2xl">
                        {suggestions.map((s, idx) => (
                          <button key={idx} type="button" onClick={() => applySuggestion(s)} className="flex w-full flex-col p-3 text-left hover:bg-white/5 border-b border-border last:border-0">
                            <strong className="text-sm text-white">{s.name}</strong>
                            <span className="text-[0.7rem] text-text-muted">{s.barcode} • {s.status}</span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                  <div className="flex flex-col gap-2">
                    <label className="text-sm font-extrabold text-white">Price (AMD)</label>
                    <div className="relative">
                      <DollarSign className="absolute top-1/2 left-4 h-5 w-5 -translate-y-1/2 text-text-muted" />
                      <input
                        type="number"
                        name="price"
                        value={editingProduct?.price ?? ""}
                        onChange={(e) => setEditingProduct({ ...editingProduct, price: Number(e.target.value) })}
                        placeholder="Գին AMD"
                        required
                        className="w-full pl-12"
                      />
                    </div>
                  </div>
                  <div className="flex flex-col gap-2">
                    <label className="text-sm font-extrabold text-white">Product Image</label>
                    <div className="flex gap-2">
                      <div className="relative flex-1">
                        <ImageIcon className="absolute top-1/2 left-4 h-5 w-5 -translate-y-1/2 text-text-muted" />
                        <input
                          type="text"
                          name="image"
                          value={editingProduct?.image || ""}
                          onChange={(e) => setEditingProduct({ ...editingProduct, image: e.target.value })}
                          placeholder="Image URL or upload →"
                          className="w-full pl-12"
                        />
                      </div>
                      <label className="flex h-12 w-12 cursor-pointer items-center justify-center rounded-lg border border-border bg-white/5 text-white hover:bg-white/10 transition-colors overflow-hidden">
                        {editingProduct?.image ? (
                          <img src={editingProduct.image} alt="Preview" className="h-full w-full object-cover" />
                        ) : (
                          <Plus className="h-5 w-5" />
                        )}
                        <input type="file" className="hidden" accept="image/*" onChange={handleImageUpload} />
                      </label>
                    </div>
                  </div>
                  <div className="flex flex-col gap-2">
                    <label className="text-sm font-extrabold text-white">Status / label</label>
                    <input
                      list="status-list"
                      name="status"
                      value={editingProduct?.status || ""}
                      onChange={(e) => setEditingProduct({ ...editingProduct, status: e.target.value })}
                      placeholder="Sale, Popular, New կամ custom"
                      className="w-full"
                    />
                    <datalist id="status-list">
                      <option value="Sale" />
                      <option value="Popular" />
                      <option value="New" />
                      <option value="In Stock" />
                    </datalist>
                  </div>
                  <div className="flex flex-col gap-2">
                    <label className="text-sm font-extrabold text-white">Unit (չափման միավոր)</label>
                    <input
                      list="unit-list"
                      name="unit"
                      value={editingProduct?.unit || ""}
                      onChange={(e) => setEditingProduct({ ...editingProduct, unit: e.target.value })}
                      placeholder="հատ, /մ, /լ"
                      className="w-full"
                    />
                    <datalist id="unit-list">
                      <option value="հատ" />
                      <option value="/մ" />
                      <option value="/լ" />
                    </datalist>
                  </div>
                </div>

                <label className="flex items-center gap-3 text-sm font-extrabold text-white cursor-pointer">
                  <input
                    type="checkbox"
                    name="pinned"
                    checked={editingProduct?.pinned || false}
                    onChange={(e) => setEditingProduct({ ...editingProduct, pinned: e.target.checked })}
                    className="h-5 w-5 rounded border-border bg-bg-main"
                  />
                  Pin product and show higher/highlighted
                </label>

                <div className="flex gap-3">
                  <button type="submit" className="flex h-12 items-center justify-center rounded-lg bg-accent px-8 font-extrabold text-white shadow-lg shadow-accent/20 hover:bg-accent-hover transition-colors">
                    {editingProduct?.id ? "Update Product" : "Save Product"}
                  </button>
                  <button type="button" onClick={() => setEditingProduct(null)} className="flex h-12 items-center justify-center rounded-lg border border-border bg-transparent px-8 font-extrabold text-white hover:bg-white/5 transition-colors">
                    Clear
                  </button>
                </div>
              </form>

              <div className="overflow-x-auto rounded-xl border border-border bg-bg-card shadow-2xl">
                <table className="w-full border-collapse text-left">
                  <thead className="bg-bg-sidebar text-xs font-extrabold text-text-muted uppercase tracking-wider">
                    <tr>
                      <th className="p-4">Product</th>
                      <th className="p-4">Barcode</th>
                      <th className="p-4">Price</th>
                      <th className="p-4">Status</th>
                      <th className="p-4 text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {products.map((p) => (
                      <tr key={p.id} className="border-t border-border group hover:bg-bg-main/30 transition-colors">
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <img src={p.image || FALLBACK_IMAGE} alt="" className="h-10 w-10 rounded border border-border object-cover" />
                            <div className="flex flex-col">
                              <span className="font-bold text-white">{p.name}</span>
                              {p.pinned && <span className="text-[0.65rem] font-extrabold text-amber-500 flex items-center gap-1 uppercase"><Pin className="h-2 w-2" /> Pinned</span>}
                            </div>
                          </div>
                        </td>
                        <td className="p-4 text-sm font-medium text-text-muted">{p.barcode}</td>
                        <td className="p-4 font-extrabold text-white">{formatPrice(p.price)}</td>
                        <td className="p-4">
                          {p.status && (
                            <span className="rounded-full bg-bg-main border border-border px-2 py-0.5 text-[0.65rem] font-extrabold text-accent uppercase">{p.status}</span>
                          )}
                        </td>
                        <td className="p-4">
                          <div className="flex items-center justify-center gap-2">
                            <button onClick={() => setEditingProduct(p)} className="p-2 text-text-muted hover:text-accent transition-colors"><Edit2 className="h-4 w-4" /></button>
                            <button onClick={() => handleDeleteProduct(p.id)} className="p-2 text-text-muted hover:text-red-500 transition-colors"><Trash2 className="h-4 w-4" /></button>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {products.length === 0 && (
                      <tr>
                        <td colSpan={5} className="p-12 text-center text-text-muted">No products yet.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === "orders" && (
            <div className="grid gap-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="eyebrow">Order management</p>
                  <h3 className="section-title text-2xl">Պատվերներ</h3>
                </div>
                <div className="rounded-full bg-accent/10 border border-accent/20 px-4 py-1 text-sm font-bold text-accent">
                  {orders.length} orders
                </div>
              </div>

              <div className="grid gap-4">
                {orders.map((o) => (
                  <div key={o.id} className="rounded-xl border border-border bg-bg-card p-5 shadow-2xl">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-lg font-extrabold tracking-widest text-white">{o.orderCode}</span>
                          <span className="rounded-full border border-accent/40 bg-accent/10 px-2.5 py-0.5 text-[0.65rem] font-extrabold text-accent uppercase">
                            {STATUS_LABELS_HY[o.status] ?? o.status}
                          </span>
                        </div>
                        <p className="mt-1 text-sm font-bold text-white">{o.customerName}</p>
                        <p className="text-xs text-text-muted">{o.customerPhone}{o.customerEmail ? ` • ${o.customerEmail}` : ""}</p>
                        <p className="text-xs text-text-muted">{o.deliveryMethod}{o.address ? ` • ${o.address}` : ""}</p>
                        {o.comment && <p className="mt-1 text-xs italic text-text-muted">«{o.comment}»</p>}
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <span className="text-lg font-extrabold text-white">{formatPrice(o.totalAmount)}</span>
                        <select
                          value={o.status}
                          disabled={statusUpdating === o.id}
                          onChange={(e) => handleStatusChange(o.id, e.target.value as OrderStatus)}
                          className="rounded-lg border border-border bg-bg-main px-3 py-2 text-sm font-bold text-white disabled:opacity-50"
                        >
                          {ORDER_STATUSES.map((s) => (
                            <option key={s} value={s}>{STATUS_LABELS_HY[s]}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <div className="mt-4 grid gap-1 border-t border-border pt-3">
                      {o.items.map((i, idx) => (
                        <div key={idx} className="flex items-center justify-between text-xs text-text-secondary">
                          <span>{i.name}</span>
                          <span className="text-text-muted">{i.quantity} {i.unit} × {formatPrice(i.price)} = {formatPrice(i.subtotal)}</span>
                        </div>
                      ))}
                    </div>
                    <time className="mt-3 block text-[0.7rem] font-bold text-text-muted uppercase tracking-wider">{new Date(o.createdAt).toLocaleString("hy-AM")}</time>
                  </div>
                ))}
                {orders.length === 0 && (
                  <div className="rounded-xl border border-dashed border-border bg-bg-card p-12 text-center text-text-muted">Պատվերներ դեռ չկան։</div>
                )}
              </div>
            </div>
          )}

          {activeTab === "messages" && (
            <div className="grid gap-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="eyebrow">Inquiries</p>
                  <h3 className="section-title text-2xl">Հաճախորդների հարցումներ</h3>
                </div>
                <div className="rounded-full bg-accent/10 border border-accent/20 px-4 py-1 text-sm font-bold text-accent">
                  {messages.length} messages
                </div>
              </div>

              <div className="grid gap-4">
                {messages.map((m) => (
                  <div key={m.id} className="relative rounded-xl border border-border bg-bg-card p-6 shadow-2xl">
                    <button onClick={() => handleDeleteMessage(m.id)} className="absolute top-4 right-4 p-2 text-text-muted hover:text-red-500 transition-colors"><Trash2 className="h-4 w-4" /></button>
                    <div className="mb-4 flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-bg-main text-accent border border-border"><Users className="h-5 w-5" /></div>
                      <div>
                        <strong className="block text-white">{m.name}</strong>
                        <span className="text-xs font-bold text-text-muted">{m.phone}</span>
                      </div>
                    </div>
                    <p className="text-text-secondary leading-relaxed">{m.message}</p>
                    <time className="mt-4 block text-[0.7rem] font-bold text-text-muted uppercase tracking-wider">{new Date(m.createdAt).toLocaleString("hy-AM")}</time>
                  </div>
                ))}
                {messages.length === 0 && (
                  <div className="rounded-xl border border-dashed border-border bg-bg-card p-12 text-center text-text-muted">Հաղորդագրություններ դեռ չկան։</div>
                )}
              </div>
            </div>
          )}

          {activeTab === "admins" && (
            <div className="grid gap-8 max-w-2xl">
              <div>
                <p className="eyebrow">User management</p>
                <h3 className="section-title text-2xl">Admin Access</h3>
              </div>

              <div className="grid gap-4">
                {admins.map((a) => (
                  <div key={a.email} className="flex items-center justify-between rounded-xl border border-border bg-bg-card p-4 shadow-lg transition-all hover:border-accent/40">
                    <div className="flex items-center gap-3">
                      <div className={cn("flex h-10 w-10 items-center justify-center rounded-full border border-border", a.role === "Main admin" ? "bg-amber-500/10 text-amber-500" : "bg-accent/10 text-accent")}>
                        <CheckCircle className="h-5 w-5" />
                      </div>
                      <div>
                        <strong className="block text-white">{a.email}</strong>
                        <span className="text-xs font-bold text-text-muted uppercase tracking-wider">{a.role}</span>
                      </div>
                    </div>
                  </div>
                ))}
                {admins.length === 0 && (
                  <div className="rounded-xl border border-dashed border-border bg-bg-card p-8 text-center text-text-muted">No admins listed.</div>
                )}
              </div>

              <div className="rounded-xl bg-accent/5 p-6 border border-accent/10">
                <p className="text-xs font-bold text-accent leading-relaxed uppercase tracking-widest">
                  <Info className="inline h-4 w-4 mr-2 mb-1" />
                  Admin users can manage the entire catalog.
                </p>
              </div>
            </div>
          )}
        </div>
      </main>

      {scannerOpen && (
        <CameraScanner
          onBarcode={onBarcodeScanned}
          onPhoto={onPhotoCaptured}
          onClose={() => setScannerOpen(false)}
        />
      )}
    </div>
  );
}