import { createFileRoute } from "@tanstack/react-router";
import LoginPage from "@/components/sosshin/LoginPage";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Admin Login | sosshin.am" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: LoginPage,
});