import { createFileRoute } from "@tanstack/react-router";
import HomePage from "@/components/sosshin/HomePage";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Sosshin — Լողավազանի սարքավորումներ | sosshin.am" },
      { name: "description", content: "Լողավազանի նասոսներ, ֆիլտրեր, PVC խողովակներ և սարքավորումներ. Sosshin pool equipment catalog." },
      { property: "og:title", content: "Sosshin — Pool Equipment Catalog" },
      { property: "og:description", content: "Pool pumps, filters, PVC pipes and valves from sosshin.am." },
      { property: "og:type", content: "website" },
    ],
  }),
  component: Index,
});

function Index() {
  return <HomePage />;
}
