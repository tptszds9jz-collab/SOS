import { createFileRoute } from "@tanstack/react-router";
import TrackOrderPage from "@/components/sosshin/TrackOrderPage";

export const Route = createFileRoute("/track-order")({
  head: () => ({
    meta: [
      { title: "Հետևել պատվերին — sosshin.am" },
      { name: "description", content: "Ստուգեք Ձեր SOS պատվերի կարգավիճակը 4-նիշանոց կոդով։" },
      { property: "og:title", content: "Հետևել պատվերին — sosshin.am" },
      { property: "og:description", content: "Ստուգեք Ձեր SOS պատվերի կարգավիճակը 4-նիշանոց կոդով։" },
    ],
  }),
  component: TrackOrderPage,
});