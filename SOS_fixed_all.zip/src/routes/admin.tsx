import { useEffect } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import AdminPage from "@/components/sosshin/AdminPage";
import { useAdminSession } from "@/lib/sosshin-auth";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Admin Dashboard | sosshin.am" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminRoute,
});

function AdminRoute() {
  const { state } = useAdminSession();
  const navigate = useNavigate();

  useEffect(() => {
    if (state === "guest") navigate({ to: "/login" });
  }, [state, navigate]);

  if (state !== "authed") {
    return (
      <div className="sosshin flex min-h-screen items-center justify-center bg-bg-main">
        <div className="h-12 w-12 animate-spin rounded-full border-4 border-accent border-t-transparent" />
      </div>
    );
  }

  return <AdminPage />;
}