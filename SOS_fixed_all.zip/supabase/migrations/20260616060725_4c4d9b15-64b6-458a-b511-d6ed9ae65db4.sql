-- 1. Restrict admin_profiles SELECT to admins only
DROP POLICY IF EXISTS "Authenticated can view admins" ON public.admin_profiles;
CREATE POLICY "Admins can view admins"
ON public.admin_profiles
FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'main_admin'::app_role));

-- 2. Restrict user_roles SELECT to the owning user (prevents role enumeration)
DROP POLICY IF EXISTS "Authenticated can read roles" ON public.user_roles;
CREATE POLICY "Users can read their own roles"
ON public.user_roles
FOR SELECT
TO authenticated
USING (user_id = auth.uid());

-- 3. Stop broadcasting customer messages (phone numbers) over Realtime
ALTER PUBLICATION supabase_realtime DROP TABLE public.messages;