# SOS / sosshin.am fixed app

This zip was repaired from a flattened Lovable/TanStack Start export.

## What was fixed

- Restored correct project structure: `src/routes`, `src/lib`, `src/components`, `src/integrations/supabase`, `supabase/migrations`.
- Added Google Custom Search settings as server-only env variables.
- Changed admin product finder from Lovable AI-only search to Google Custom Search, so approximate product names return real web results.
- Kept Google image search for selecting product images.
- Kept cart, order tracking, order admin statuses, and customer confirmation email code.
- Added `.env.example` and `.env.local`.

## Run locally

```bash
npm install
npm run dev
```

## Important env notes

Google Search keys are read on the server as:

```bash
GOOGLE_SEARCH_API_KEY=...
GOOGLE_SEARCH_ENGINE_ID=...
```

Do not use `VITE_` for these Google keys, because `VITE_` variables are bundled into the browser.

For order creation/status emails outside Lovable Cloud, also add:

```bash
SUPABASE_SERVICE_ROLE_KEY=...
LOVABLE_API_KEY=...
GOOGLE_MAIL_API_KEY=...
SITE_URL=https://your-domain.com
```

## Database

Apply the SQL files inside `supabase/migrations` to your Supabase project.

## Admin

Existing admin login should continue through Supabase Auth and `user_roles`:

- main admin/admin roles can manage products/orders/messages
- public users can browse catalog and create cart orders
